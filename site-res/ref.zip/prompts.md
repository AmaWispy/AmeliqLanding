# Промпты для генерации изображений портфолио

Стиль: Современный, Dark Mode, Tech, Neon, High-End UI.
Соотношение сторон: Рекомендуется 16:9 или 4:3.

---

## 1. Салон красоты (Beauty Salon)
*Эстетика, неон, элегантность.*

**Вариант 1 (Интерфейс/Мокап):**
> Minimalist beauty salon website landing page mockup on a laptop screen, dark mode UI, elegant pink and gold accents, floating 3D abstract cosmetics elements, soft studio lighting, 8k, unreal engine render, futuristic layout --ar 16:9

**Вариант 2 (Атмосфера):**
> Cyberpunk aesthetic beauty salon interior, neon pink lighting, sleek modern furniture, glass surfaces, cinematic shot, high contrast, professional photography, depth of field, dark atmosphere --ar 16:9

**Вариант 3 (Абстракция):**
> Abstract beauty concept, fluid liquid gold and pink neon shapes, dark background, glossy texture, high fashion aesthetic, 3d render, octane render --ar 4:3

---

## 2. Автосервис (Auto Service)
*Технологии, механизм, надежность.*

**Hero Background (Фон первого экрана):**
> Modern auto service workshop interior, wide angle shot, mechanic working on a luxury car on a lift, clean and organized garage, cinematic lighting, depth of field, professional atmosphere, 8k, realistic --ar 16:9

**Promo Banner (Фон для акции):**
> Close up of car suspension parts, shock absorber and brake disc, dramatic lighting, dark background with red accents, high detail, automotive photography style, 4k --ar 16:9

**Услуги (Миниатюры/Фоны):**
*   **Двигатель:** `Car engine close-up, clean metallic parts, professional mechanic hand adjusting a valve, high tech look --ar 4:3`
*   **ТО:** `Mechanic pouring oil into car engine, golden oil flow, clean workshop environment, professional service --ar 4:3`
*   **Подвеска:** `Car suspension system from underneath, wheel removed, mechanic inspecting brake pads, realistic, detailed --ar 4:3`
*   **Электрика:** `Car dashboard diagnostics, laptop connected to car OBD port, digital graphs and codes on screen, dark interior, neon light accents --ar 4:3`

---

## 3. Онлайн-курс (Online Course)
*Образование, цифровой разум, прогресс.*

**Hero Image (Студент/Процесс обучения):**
> Young creative woman designer working on a laptop in a modern bright co-working space, holding a stylus, figma interface on screen, coffee cup on table, natural sunlight, inspirational atmosphere, high quality photography, 4k --ar 4:3

**Author Portrait (Автор курса - Алина Соколова):**
> Professional portrait of a confident young woman product designer, wearing smart casual clothes, standing in a modern design studio office, friendly smile, soft depth of field background, studio lighting, high resolution --ar 3:4

**Review Avatars (Аватарки студентов):**
*   **Анна:** `Portrait of a happy young female student with glasses, bright background, natural lighting, smile --ar 1:1`
*   **Дмитрий:** `Portrait of a focused young man developer, casual hoodie, modern office background, looking at camera --ar 1:1`
*   **Елена:** `Portrait of a woman freelancer working at home, cozy atmosphere, warm lighting, friendly expression --ar 1:1`

**Portfolio Preview (Превью для карточки кейса):**

**Вариант 1 (Интерфейс/Мокап):**
> E-learning platform interface mockup on a desktop monitor, displaying a video course about web design, colorful UI elements, purple and pink gradient accents, clean minimal desk setup, isometric view, 3d render --ar 16:9

**Вариант 2 (Абстракция/Концепт):**
> Abstract representation of online learning, glowing neural network connections forming a graduation cap, purple and blue neon gradients, floating education icons and certificates, dark background, 3D render, futuristic education concept --ar 16:9

**Вариант 3 (Рабочее место/Атмосфера):**
> Modern home office setup for online learning, macbook with coding course on screen, ambient violet and pink lighting, cozy but high-tech atmosphere, plant in background, shallow depth of field, photorealistic, inspirational workspace --ar 16:9

**Вариант 4 (UI/UX Фокус):**
> E-learning dashboard interface on tablet and phone mockup, dark mode, progress bars, video player, achievement badges, vibrant purple and pink accents, clean modern ui/ux design, glassmorphism effects, premium look --ar 16:9

---

## 4. Ваш проект (Заглушка)
*Для карточки "Ваш проект"*

> Abstract question mark made of glowing neon wires, dark background with fog, mystery, potential, future project concept, cinematic lighting, 3d render --ar 4:3
