jQuery(function($){var App
App=(function(){function App(){this.init()}
App.prototype.init=function(){this.actions()
return this['static']()}
App.prototype.phoneMask=function(input){var fk
fk=input.charAt(0)
if(fk==='8'){return['8',' ','(',/\d/,/\d/,/\d/,')',' ',/\d/,/\d/,/\d/,'-',/\d/,/\d/,'-',/\d/,/\d/,]}else if(fk==="7"){return['+',/\d/,' ','(',/\d/,/\d/,/\d/,')',' ',/\d/,/\d/,/\d/,'-',/\d/,/\d/,'-',/\d/,/\d/,]}else{return['+','7',' ','(',/\d/,/\d/,/\d/,')',' ',/\d/,/\d/,/\d/,'-',/\d/,/\d/,'-',/\d/,/\d/,]}}
App.prototype['static']=function(){var self
self=this
if(typeof vanillaTextMask==='object'){$('input[type="tel"], input[name="phone"]').each(function(ind,node){return vanillaTextMask.maskInput({inputElement:node,mask:self.phoneMask,})})}
$(document.body).on('click','[data-action="toggle-menu"]',function(){return self.toggleMenu()})
return $(document.body).on('click','.nav-menu .toggler',function(event){return self.slideToggleMenu(this,event)})}
App.prototype.toggleMenu=function(){$('[data-action="toggle-menu"]').toggleClass('open')
return $('#theme-header .menu-holder').toggleClass('open')}
App.prototype.slideToggleMenu=function(toggler,event){var li,smh,t
event.preventDefault()
event.stopPropagation()
console.log(toggler)
t=$(toggler)
li=t.closest('.nav-menu-element')
smh=li.find(' > .sub-menu-holder')
return smh.slideToggle(200,function(){return li.toggleClass('open')})}
App.prototype.actions=function(){var self
self=this
return $(document).on('click','[data-action="send"],[data-target="modal"]',function(e){var callee,type
e.preventDefault()
e.stopPropagation()
callee=$(this)
type=callee.data('action')
return self.triggerAction(type,callee)})}
App.prototype.triggerAction=function(type,callee){switch(type){case'send':return this.sendForm(callee)
default:return this.openModal(type,callee)}}
App.prototype.sppLink=function(text){if(text==null){text=''}
if(window.spp_link){return('<a href="'+window.spp_link+'" target="_blank">'+text+'</a>')}else{return text}}
App.prototype.guidGenerator=function(){var S4
S4=function(){return(((1+Math.random())*0x10000)|0).toString(16).substring(1)}
return'id_'+S4()+'_'+S4()+'_'+S4()+'_'+S4()+'_'+S4()}
App.prototype.sendForm=function(callee){var eform,fe,form
eform=callee.parents('.form')
eform.find('.error').removeClass('error')
form=eform.eserialize()
if(form.status!==true){fe=$(form.error)
setTimeout(function(){return fe.addClass('error')},10)
if(window.TOtriggers){clearTimeout(window.TOtriggers['rcerror'])}
return setTimeout(function(){return fe.removeClass('error')},5000,'rcerror')}else{if(!form.data.get('type')){form.data.append('type','request')}
form.data.append('formsubmit',true)
return $.ajax({url:'/wp-json/gse/form/send',processData:false,contentType:false,dataType:'json',data:form.data,method:'POST',success:function(response){if(response.status){var config,modal
config={title:'Ваш запрос отправлен',content:false,buttons:[],timeout:400,autoopen:true,}
modal=new Modal(config)
return eform.find('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea').val('')}else{return this.error(response)}},error:function(response){var config,modal
config={title:'Произошла ошибка',content:false,buttons:[],timeout:400,autoopen:true,}
return(modal=new Modal(config))},})}}
App.prototype.openModal=function(type,callee){var block,blocks,btn1,config,container,i,j,len,modal,product,rid,self,spp,title
self=this
rid=this.guidGenerator()
container=$('<form>',{class:'form',})
blocks=[]
var ym_target=callee.data('ym-target')
blocks[1]=$('<div>',{class:'input',}).html(`<input type="hidden" name="URL" value="${window.location.href}"><input type="tel" id="${rid}-phone" name="phone" placeholder="Телефон*" required><div class="error-msg">Поле обязательно к заполнению</div>`);title='Заказать звонок';switch(type){case'request':title='Узнать подробнее'
break
case'dolyame':title='ХОЧУ ОПЛАТИТЬ ДОЛЯМИ'
i=$('<div>',{class:'modal-header-subtitle',}).html('Мы с вами свяжемся, определим общую стоимость и сумму платежа')
blocks[0]=i
break
case'brif':title='Заполнить бриф'
i=$('<div>',{class:'input',}).html('<textarea id="'+
rid+'-message" name="message" placeholder="Сообщение">')
blocks.push(i)
break
case'order':title='Заказать'
product=callee.data('product')
if(product){i=$('<input>',{type:'hidden',id:rid+'-product',name:'product',value:product,})
blocks.push(i)}
break
case'buy':title='Получить предложение'
var prod=$('.modal-buy').attr('data-product')
i=$('<input>',{type:'hidden',id:rid+'-product',name:'product',value:prod,})
p=$('<div>',{class:'input',}).html('<input type="text" id="'+
rid+'-mail" name="mail" placeholder="email">')
blocks.push(i)
blocks.push(p)}
spp=$('<div>',{"class":'input spp-input'}).html('<input type="checkbox" id="'+rid+'-spp" name="spp" required><label for="'+rid+'-spp">Я согласен с '+self.sppLink('условиями обработки персональных данных')+'</label><div class="error-msg">Мы не можем принять ваше обращение без данного согласия</div>');blocks.push(spp);for(j=0,len=blocks.length;j<len;j++){block=blocks[j]
container.append(block)}
btn1=$('<button>',{type:'submit',name:'formsubmit',value:'formsubmit',}).html('Отправить')
config={title:title,content:container,buttons:[btn1],timeout:400,autoopen:true,}
modal=new Modal(config)
$('input[type="tel"]',container).each(function(ind,node){return vanillaTextMask.maskInput({inputElement:node,mask:self.phoneMask,})})
return btn1.on('click',function(){var f,fe,form
f=modal.modal_dialog.find('.form')
f.find('.error').removeClass('error')
form=f.eserialize()
if(form.status!==true){fe=$(form.error)
setTimeout(function(){return fe.addClass('error')},10)
if(window.TOtriggers){clearTimeout(window.TOtriggers['rcerror'])}
return setTimeout(function(){return fe.removeClass('error')},5000,'rcerror')}else{if(!form.data['type']){form.data['type']=type}
return $.ajax({url:'/wp-json/gse/form/send',processData:false,contentType:false,dataType:'json',data:form.data,method:'POST',success:function(response){if(response.status){$(document.body).trigger({type:'ajaxformforyandexmetrika',eventData:{trigger:callee,},})
modal.modal_header_title.html('Ваш запрос отправлен')
modal.modal_content.html('<div class="success-msg"><p> Сейчас мы отдыхаем, поэтому перезвоним Вам в первый рабочий день. <br> Дарим скидку 10% на любую нашу услугу по промокоду</p><strong>HappyNewYear10</strong><div>')
modal.modal_content.remove()
modal.modal_footer.remove()
if(ym_target&&'metrika_id'in window&&window.metrika_id){try{ym(window.metrika_id,'reachGoal',ym_target)}catch(e){}}}else{return this.error(response)}},error:function(response){var err_config,err_modal
err_config={title:'Произошла ошибка',content:false,buttons:[],timeout:400,autoopen:true,}
return(err_modal=new Modal(err_config))},})}})}
return App})()
$('document').ready(function(){return new App()})
$(window).scroll(function(){var st=$(window).scrollTop()
var range=400
var opacity=1.8-st/range
if(opacity<0){opacity=0}
if(opacity>1){opacity=1}
$('.slider-video-block').css('opacity',opacity)})
$(window).scroll(function(){var works_block=document.querySelector('.works-section')
if(works_block){var top=works_block.getBoundingClientRect().top
let x=236
let y=236
let z=236
if(top<1500&&top>0){x=x+-top*-0.02
y=y+-top*-0.02
z=z+-top*-0.02}
let param='rgb('+x+', '+y+', '+z+')'
$('.works-section').css('background',param)}})
function getVakancyForm(modal,props){const id=props['data-modal'].value
const targetBtn=props[0].ownerElement
$(modal).find('.privacy input[type="checkbox"]').prop('checked',true)
let html=''
const data=JSON.parse(targetBtn.getAttribute('data-body'))
html+='<div class="modal-top">'
if(data.title){html+='<h2 class="title">'+data.title+'</h2>'}
if(data.salary){html+='<div class="salary">'+data.salary+'</div>'}
if(data.experience||data.employment_type){html+='<div class="wrapper-short-description">'
if(data.experience){html+='<div class="experience">Требуемый опыт работы: '+
data.experience+'</div>'}
if(data.employment_type){html+='<div class="employment-type">'+data.employment_type+'</div>'}
html+='</div>'}
html+='</div>'
if(data.vacancy_description){html+='<div class="modal-middle-wrap">'
html+='<div class="modal-middle">'+data.vacancy_description+'</div>'
html+='</div>'}
$(modal).find('.modal-vakancy__body').html(html)
$(modal).find('input[name="vacancy-title"]').val(data.title)
let bodyScrollBar=modal.querySelector('.modal-vakancy__body .modal-middle')
if(bodyScrollBar){new SimpleBar(bodyScrollBar,{autoHide:false,})}
ThemeModal.getInstance().openModal(id)}
function getPercentForm(modal,props){const id=props['data-modal'].value
const targetBtn=props[0].ownerElement;let percentValue=$('.grampus-timer__active-percent span').text();$(modal).find('.modal-percent__title').html(`Ваша скидка ${percentValue}`);$(modal).find('input[name=percent]').val(percentValue);ThemeModal.getInstance().openModal(id)}
const themeModal=new ThemeModal({mouseup:true})
themeModal.init()
themeModal.modalsView['vakancy']={callback:getVakancyForm,}
themeModal.modalsView['percent']={callback:getPercentForm,}
$('#modal-success .closed-modal').on('click',function(){ThemeModal.getInstance().closeModal()})
document.addEventListener('wpcf7mailsent',function(event){var $form=$(event.target)
var $form_h=$form.closest('[data-ym-target]')
if($form_h.length>0){var ym_target=$form_h.data('ym-target')
if(ym_target&&'metrika_id'in window&&window.metrika_id){try{ym(window.metrika_id,'reachGoal',ym_target)}catch(e){}}}},false)
$(document).ready(function($){setTimeout(function(){ym(92539234,'reachGoal','30sek')},30000)})
$(document.body).on('ajaxformforyandexmetrika',function(e){ym(92539234,'reachGoal','jsotpravkaformy')})
$(document.body).on('wpcf7mailsent',function(e){ym(92539234,'reachGoal','jsotpravkaformy')})
if($(document.body).hasClass('front-page')){$(document.body).on('wpcf7mailsent',function(e){var btn=$(e.target).find('input[data-yandex]')
if(!btn)return
var btnDate=btn.attr('data-yandex')
switch(btnDate){case'main_form_bottom':ym(92539234,'reachGoal','main_form_bottom')
break}})}
if($(document.body).hasClass('audit-page')){$(document.body).on('click','a.phone',()=>{ym(92539234,'reachGoal','otpravkaform')})
$(document.body).on('ajaxformforyandexmetrika',function(e){var btn=e.eventData.trigger.attr('data-yandex')
switch(btn){case'obsud.pro':ym(92539234,'reachGoal','otpravkaform')
break
case'audit_order':ym(92539234,'reachGoal','audit_rk')
break
case'formats_order-1':ym(92539234,'reachGoal','online_kons')
break
case'formats_order-2':ym(92539234,'reachGoal','mail_audit')
break
case'audit_results':ym(92539234,'reachGoal','want_too')
break
case'podval.obsudstoim':ym(92539234,'reachGoal','discuss_project')
break}})
$(document.body).on('wpcf7mailsent',function(e){var btn=$(e.target).find('input[data-yandex]')
if(!btn)return
var btnDate=btn.attr('data-yandex')
switch(btnDate){case'audit_form':ym(92539234,'reachGoal','full_audit')
break
case'audit_form_two':ym(92539234,'reachGoal','leave_request')
break
case'franchise_form':ym(92539234,'reachGoal','get_consultation')
break}})}
if($(document.body).hasClass('nastroyka-yandeks-direkt-page')){$(document.body).on('click','a.phone',()=>{ym(92539234,'reachGoal','otpravitzayavku')})
$(document.body).on('ajaxformforyandexmetrika',function(e){var btn=e.eventData.trigger.attr('data-yandex')
switch(btn){case'obsud.pro':ym(92539234,'reachGoal','otpravitzayavku')
break
case'direct_mainbanner_order':ym(92539234,'reachGoal','nynachat')
break
case'annotation_two':ym(92539234,'reachGoal','nyraschet')
break
case'direct_price':ym(92539234,'reachGoal','nyobsudit')
break
case'direct_management_0':ym(92539234,'reachGoal','nytarifmin')
break
case'direct_management_1':ym(92539234,'reachGoal','nytarifopt')
break
case'direct_management_2':ym(92539234,'reachGoal','nytarifrash')
break
case'podval.obsudstoim':ym(92539234,'reachGoal','otpravitzayavku')
break
case'hochu_nastrojku':ym(92539234,'reachGoal','nyhochutakje')
break
case'mne_nujna_reklama':ym(92539234,'reachGoal','nynuzhnareklama')
break}})
$(document.body).on('wpcf7mailsent',function(e){var btn=$(e.target).find('input[data-yandex]')
if(!btn)return
var btnDate=btn.attr('data-yandex')
switch(btnDate){case'direct_one_form':ym(92539234,'reachGoal','nyanalizdirect')
break
case'direct_two_form':ym(92539234,'reachGoal','nyakeysform')
break
case'audit_form_two':ym(92539234,'reachGoal','nyzayavkanaaudit')
break
case'direct_three_form':ym(92539234,'reachGoal','nysaleform')
break
case'contacts_from_not_map':ym(92539234,'reachGoal','nybesplkonsult')
break
case'contact_form_employee':ym(92539234,'reachGoal','nyformniz')
break}})}
if($(document.body).hasClass('nastrojka-kontekstnoj-reklamy-page')){$(document.body).on('click','a.phone',()=>{ym(92539234,'reachGoal','otpravitzayavku')})
$(document.body).on('ajaxformforyandexmetrika',function(e){var btn=e.eventData.trigger.attr('data-yandex')
switch(btn){case'banner_direct':ym(92539234,'reachGoal','nkrkolvozayavok')
break
case'nachat_sotrudnichestvo':ym(92539234,'reachGoal','nkrnachatsotrudnichestvo')
break
case'mne_nujna_reklama_second':ym(92539234,'reachGoal','nkrmnenuzhnareklama')
break}})
$(document.body).on('wpcf7mailsent',function(e){var btn=$(e.target).find('input[data-yandex]')
if(!btn)return
var btnDate=btn.attr('data-yandex')
switch(btnDate){case'poluchit_audit':ym(92539234,'reachGoal','nkraudittovara')
break
case'poluchit_podarok':ym(92539234,'reachGoal','nkrmesvpodarok')
break}})}
if($(document.body).hasClass('sozdanie-sajtov-page')){$(document.body).on('click','a.phone',()=>{ym(92539234,'reachGoal','otpravitzayavku')})
$(document.body).on('ajaxformforyandexmetrika',function(e){var btn=e.eventData.trigger.attr('data-yandex')
switch(btn){case'obsudit_project':ym(92539234,'reachGoal','ssobsuditproekt')
break
case'dolyami':ym(92539234,'reachGoal','ssrassrochka')
break}})
$(document.body).on('wpcf7mailsent',function(e){var btn=$(e.target).find('input[data-yandex]')
if(!btn)return
var btnDate=btn.attr('data-yandex')
switch(btnDate){case'besplatnaya_consultaciya':ym(92539234,'reachGoal','ssbesplkons')
break
case'uzkaya_temnaya':ym(92539234,'reachGoal','sssomnevform')
break
case'ceny_na_razrabotku':ym(92539234,'reachGoal','sspriceform')
break}})}
const createSlider=section=>{let slider=section.querySelector('.swiper')
let navNext=section.querySelector('.slider-btn--next')
let navPrev=section.querySelector('.slider-btn--prev')
new Swiper(slider,{slidesPerView:1,spaceBetween:20,speed:800,navigation:{nextEl:navNext,prevEl:navPrev,},breakpoints:{320:{slidesPerView:1,spaceBetween:15,},768:{slidesPerView:2,spaceBetween:30,},},})}
let blogSlider=document.querySelectorAll('.blog-other')
blogSlider.forEach(createSlider)
$('ul.nav-menu .nav-menu-element[data-nav]').hover(function(){let idMenu=$(this).data('nav')
$(`[data-menu="${idMenu}"]`).addClass('active')
$(this).addClass('nav-active')},function(){let idMenu=$(this).data('nav')
$(`[data-menu="${idMenu}"]`).removeClass('active')
$(this).removeClass('nav-active')})
let isPainted=false;let thresholdAdd=50;let thresholdRemove=10;function handleScroll(){const scrollPosition=$(this).scrollTop();if(scrollPosition>thresholdAdd&&!isPainted){$(".main-header.no-background").addClass("painted");isPainted=true;}else if(scrollPosition<thresholdRemove&&isPainted){$(".main-header.no-background").removeClass("painted");isPainted=false;}}
$(document).scroll(debounce(handleScroll,10));$('[data-menu]').hover(function(){let idMenu=$(this).data('menu')
$(`ul.nav-menu .nav-menu-element[data-nav="${idMenu}"]`).addClass('nav-active')},function(){let idMenu=$(this).data('menu')
$(`ul.nav-menu .nav-menu-element[data-nav="${idMenu}"]`).removeClass('nav-active')})
$('form p').each(function(){var input_text='<span class="wpcf7-form-control-wrap" data-name="url"><input type="hidden" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false"  value="'+
document.location.href+'" name="url" data-gtm-form-interact-field-id="0"></span>'
$(this).append(input_text)})
$('form').each(function(){$(this).append('<input type="hidden" name="URL" value="'+window.location.href+'">');});$('.email').bind('copy',function(){console.log('1');yaCounter92539234.reachGoal('copy_email');return true;});$('.tile__body').bind('copy',function(){console.log('1');yaCounter92539234.reachGoal('copy_email');return true;});$('.phone').bind('copy',function(){console.log('1');yaCounter92539234.reachGoal('copy_phone');return true;});if($('#modal-fortune-wheel').length){const phoneInput=$('#modal-fortune-wheel input[name=phone]');const acceptance=$('#modal-fortune-wheel input[name=acceptance-694]');const bonusInput=$('#modal-fortune-wheel input[name=bonus]');const btn=$('#modal-fortune-wheel .btn');const wheel=document.querySelector('#modal-fortune-wheel ul.wheel-of-fortune');const arrow=document.querySelector('#modal-fortune-wheel .fortune-arrow');phoneInput.on('input',function(ev){if($(this).val().length>=18&&!$(this).val().includes('_')){if(acceptance.prop('checked')){btn.removeAttr('disabled');}else{btn.prop('disabled',true);}}else{btn.prop('disabled',true);}});acceptance.on('change',function(ev){if($(this).prop('checked')){if(phoneInput.val().length>=18){btn.removeAttr('disabled');}else{btn.prop('disabled',true);}}else{btn.prop('disabled',true);}});btn.on('click',function(){btn.prop('disabled',true);spinWheel();$('#modal-fortune-wheel .spinning-screen').addClass('active').siblings().removeClass('active');});function spinWheel(){let animation;let previousEndDegree=0;if(animation){animation.cancel();}
const randomAdditionalDegrees=Math.random()*360+1800;const newEndDegree=previousEndDegree+randomAdditionalDegrees;animation=wheel.animate([{transform:`rotate(${previousEndDegree}deg)`},{transform:`rotate(${newEndDegree}deg)`}],{duration:4000,direction:'normal',easing:'cubic-bezier(0.440, -0.205, 0.000, 1.130)',fill:'forwards',iterations:1});previousEndDegree=newEndDegree;animation.onfinish=()=>{const result=getSpinResult();bonusInput.val(result);$('#modal-fortune-wheel .result-screen').find('.screen-win span').html(result);$('#modal-fortune-wheel .result-screen').addClass('active').siblings().removeClass('active');$('#modal-fortune-wheel form .hidden-submit').trigger('click');disableFortuneWheel();}
return true;}
function getSpinResult(){if(!wheel)return null;const rect=arrow.getBoundingClientRect();const element=document.elementFromPoint(rect.x+rect.width+1,rect.top+rect.height/2);if(element?.parentElement!==wheel)return null;return element?.textContent?.trim()||null;}
setTimeout(()=>{if(isCanShowFortuneWheel()!=='true'){return;}
ThemeModal.getInstance().openModal('fortune-wheel');disableFortuneWheel();},1000*30*5);const debouncedMouseMoveTriggerFortuneWheel=debounce(MouseMoveTriggerFortuneWheel,100);$(document).on('mousemove',debouncedMouseMoveTriggerFortuneWheel);function MouseMoveTriggerFortuneWheel(ev){if(ev.clientY<20){if(isCanShowFortuneWheel()!=='true'){$(document).off('mousemove',debouncedMouseMoveTriggerFortuneWheel);return;}
if(!$('#modal-fortune-wheel').hasClass('modal-open')){ThemeModal.getInstance().openModal('fortune-wheel');disableFortuneWheel();$(document).off('mousemove',debouncedMouseMoveTriggerFortuneWheel);}}}
function disableFortuneWheel(){localStorage.setItem('FORTUNE_WHEEL_ENABLE','false');return true;}
function enableFortuneWheel(){localStorage.setItem('FORTUNE_WHEEL_ENABLE','true');return true;}
function isCanShowFortuneWheel(){return localStorage.getItem('FORTUNE_WHEEL_ENABLE')??'true';}}
const YM_UID=localStorage.getItem('_ym_uid');if(YM_UID){const current_url=new URL(window.location);if(!current_url.searchParams.get('_ym_uid')){current_url.searchParams.set("_ym_uid",YM_UID.replaceAll('"',""));history.pushState({},"",current_url);}}});function debounce(func,wait){let timeout;return function(){const context=this,args=arguments;clearTimeout(timeout);timeout=setTimeout(function(){func.apply(context,args);},wait);};}
document.addEventListener('wpcf7mailsent',function(e){if(e.detail&&String(e.detail.contactFormId)==='21098'){ym(92593234,'reachGoal','fw_submit');}},false);